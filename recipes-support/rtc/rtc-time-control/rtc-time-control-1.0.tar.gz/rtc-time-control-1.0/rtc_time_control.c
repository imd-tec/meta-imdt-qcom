/*
 * ---------------------------------------------------------------------------
 *  Copyright (c) 2026 Qualcomm Technologies, Inc.
 *  All Rights Reserved.
 *  Confidential and Proprietary - Qualcomm Technologies, Inc.
 * ---------------------------------------------------------------------------
 *
 * rtc_time_control.c - Application to set system time using time-genoff API
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <time.h>
#include "localdefs.h"
#include "time_genoff_i.h"

#define APP_NAME "rtc_time_control"

/* Function prototypes */
extern int time_genoff_operation(time_genoff_info_type *pargs);

/**
 * print_usage - Display usage information
 */
static void print_usage(void)
{
	printf("Usage: %s [OPTIONS]\n", APP_NAME);
	printf("\nOptions:\n");
	printf("  <seconds>    Set system time to specified Unix timestamp (seconds since epoch)\n");
	printf("  --get        Get and display current system time\n");
	printf("  --help       Display this help message\n");
	printf("\nExamples:\n");
	printf("  %s 1709985832        # Set time to specific timestamp\n", APP_NAME);
	printf("  %s --get             # Get current time\n", APP_NAME);
}

/**
 * set_system_time - Set system time using time-genoff API
 * @seconds: Time in seconds since Unix epoch (Jan 1, 1970)
 *
 * Returns: 0 on success, -1 on failure
 */
static int set_system_time(uint64_t seconds)
{
	time_genoff_info_type time_info;
	int ret;

	/* Validate input - reasonable range check */
	if (seconds == 0) {
		printf("Error: Invalid time value (0)\n");
		return -1;
	}

	/* Prepare time_genoff_info structure */
	memset(&time_info, 0, sizeof(time_info));
	time_info.base = ATS_TOD_GEN;
	time_info.unit = TIME_SECS;
	time_info.operation = T_SET;
	time_info.ts_val = &seconds;

	printf("Setting system time to %llu seconds since epoch...\n",
	       (unsigned long long)seconds);

	/* Call time-genoff API */
	ret = time_genoff_operation(&time_info);
	if (ret != 0) {
		printf("Error: Failed to set system time (ret=%d)\n", ret);
		return -1;
	}

	printf("System time set successfully\n");
	return 0;
}

/**
 * get_system_time - Get current system time using time-genoff API
 *
 * Returns: 0 on success, -1 on failure
 */
static int get_system_time(void)
{
	time_genoff_info_type time_info;
	uint64_t seconds = 0;
	int ret;
	time_t time_val;
	struct tm *tm_info;
	char time_str[64];

	/* Prepare time_genoff_info structure */
	memset(&time_info, 0, sizeof(time_info));
	time_info.base = ATS_TOD_GEN;
	time_info.unit = TIME_SECS;
	time_info.operation = T_GET;
	time_info.ts_val = &seconds;

	/* Call time-genoff API */
	ret = time_genoff_operation(&time_info);
	if (ret != 0) {
		printf("Error: Failed to get system time (ret=%d)\n", ret);
		return -1;
	}

	printf("Current system time: %llu seconds since epoch\n",
	       (unsigned long long)seconds);

	/* Convert to human-readable format */
	time_val = (time_t)seconds;
	tm_info = gmtime(&time_val);
	if (tm_info != NULL) {
		if (strftime(time_str, sizeof(time_str),
		             "%Y-%m-%d %H:%M:%S UTC", tm_info) > 0) {
			printf("Human-readable: %s\n", time_str);
		}
	}

	return 0;
}

/**
 * main - Entry point for time_set_app
 */
int main(int argc, char *argv[])
{
	uint64_t seconds;
	char *endptr;

	/* Check arguments */
	if (argc < 2) {
		printf("Error: Missing arguments\n\n");
		print_usage();
		return EXIT_FAILURE;
	}

	/* Handle --help option */
	if (strcmp(argv[1], "--help") == 0 || strcmp(argv[1], "-h") == 0) {
		print_usage();
		return EXIT_SUCCESS;
	}

	/* Handle --get option */
	if (strcmp(argv[1], "--get") == 0) {
		if (get_system_time() != 0) {
			return EXIT_FAILURE;
		}
		return EXIT_SUCCESS;
	}

	/* Parse seconds value */
	errno = 0;
	seconds = strtoull(argv[1], &endptr, 10);

	/* Validate conversion */
	if (errno != 0) {
		printf("Error: Invalid number format: %s\n", strerror(errno));
		return EXIT_FAILURE;
	}

	if (endptr == argv[1] || *endptr != '\0') {
		printf("Error: Invalid number format\n");
		return EXIT_FAILURE;
	}

	/* Set the time */
	if (set_system_time(seconds) != 0) {
		return EXIT_FAILURE;
	}

	/* Verify by getting the time */
	printf("\nVerifying time setting:\n");
	if (get_system_time() != 0) {
		printf("Warning: Could not verify time setting\n");
	}

	return EXIT_SUCCESS;
}
